Les param�trages
cette version n'est qu'une ebauche. 
---------------------------------
Dans le fichier ping_range.bat ligne 18 mettre les trois premier nombre de votre reseau a la maison, ligne 17 egal la dernier ip.
Le fichier hellowifi.prod le cron et a modifier �dit� le.

